export interface Note {
    id: number;
    picture?: string;
    title: string;
    description?: string;
    date: string;
    reporter?: string;
    section: string;
    city?: string;
    hour?: string;
}