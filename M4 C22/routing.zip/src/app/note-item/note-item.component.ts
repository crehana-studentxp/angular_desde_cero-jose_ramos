import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-note-item',
  templateUrl: './note-item.component.html',
  styleUrls: ['./note-item.component.scss']
})
export class NoteItemComponent implements OnInit {
  @Input() title = '';
  @Input() date = '';
  @Input() section = '';
  @Output() emitterHijo = new EventEmitter<string>();
  constructor() { }

  ngOnInit(): void {
  }

  sendEmitter():void {
    this.emitterHijo.emit(this.title);
  }

}
