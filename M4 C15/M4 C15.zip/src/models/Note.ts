export interface Note {
    title: string;
    description: string;
    date: string;
    reporter: string;
    section: string;
}