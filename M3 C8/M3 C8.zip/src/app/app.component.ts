import { Component } from '@angular/core';
import { Note } from 'src/models/Note';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'angular-noticias-test';
  list : string[] = ['elemento 1' , 'elemento 2'];
  quantity = 2;
  isActive = true;

  constructor() {
    this.list = [23, 4343, 4545];
    this.quantity = ''
    this.isActive = '';

    const myNote: Note = {date:"", description:"", reporter: "", section: "", title:""};
  }

}
