import { Component } from '@angular/core';
import { Note } from 'src/models/Note';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'angular-noticias-test';
  list : string[] = ['elemento 1' , 'elemento 2'];
  quantity = 2;
  isActive = true;
  saludo='Hola desde el archivo de TypeScript';
  edad = 18;

  imgUrl= 'https://images.unsplash.com/photo-1417325384643-aac51acc9e5d?q=75&fm=jpg&w=1080&fit=max';
  isDisabled = true;
  customerName = '';
  showBorder = '';
  activate = true;
  showElement = false;
  listProducts = ['tomate', 'papa', 'arroz', 'frijoles', 'pan'];
  listProductsObj = [{name: 'Xavier'}, {name: 'Roberto'}, {name: 'Luis'}];
  option = 0;
  noteList = [{title: 'titulo 1', date: '29/May/1992', section: 'Seccion1'}, {title: 'titulo 2', date: '29/May/1992', section: 'Seccion2'}]


  constructor() {
    const myNote: Note = {date:'', description:'', reporter: '', section: '', title:''};
  }

  helloFn(): string {
    return 'Hola desde la función helloFn';
  }

  clickEvent(): void {
    alert('Haciendo click en el botón!');
  }

  keyPressEvent($event: Event) {
    console.log($event);
  }

  // toggleBorder():void {
  //   this.showBorder = !this.showBorder;
  // }

  blueBorder(): void {
    this.showBorder = 'blue';
  }
  redBorder(): void {
    this.showBorder = 'red';
  }
  yellowBorder(): void {
    this.showBorder = 'yellow';
  }
}
